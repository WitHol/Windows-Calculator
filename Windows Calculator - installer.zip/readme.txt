This is my (very poorly made) calculator. I only created it so that I could play around with installing files on Windows.

To install the calculator extract the folder if it's zipped and run install_script.bat. This will create a folder C:\ProgramFiles\Windows Calculator and put calculator.exe in it.
It also adds a shortcut in start menu ("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Windows Calculator.lnk) and copys Windows Calculator uninstaller.bat there.

In order to uninstall, you need to run Windows Calculator uninstaller.bat, either from this folder or start menu. This will delete C:\Program Files\Windows Calculator as well as the shortcut
and an uninstaller in the start menu directory